<?php

namespace xoapp\clyde\utils;

class ItemName
{

    const FREEZE = "&gFreeze";

    const PLAYER_INFO = "&aPlayer Information";

    const TELEPORT = "&6Teleport";

    const INVENTORY_SEE = "&eInventory See";

    const ENDER_INVENTORY_SEE = "&5Ender Inventory See";

    const VANISH = "&aVanish";

    const UN_VANISH = "&cUnVanish";

    const PUNISHMENT = "&6Punishment";

}