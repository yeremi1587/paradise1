<?php

namespace xoapp\clyde\utils;

class DiscordUtils
{

    /**
     * TODO: Give me a second.
     */
    public static function sendPermanently(array $data): void
    {

    }

    /**
     * TODO: Give me a second.
     */
    public static function sendTemporary(array $data): void
    {

    }

    /**
     * TODO: Give me a second.
     */
    public static function sendKick(array $data): void
    {

    }
}