<?php

namespace xoapp\clyde\utils;

class Prefixes
{

    const GLOBAL = "§8(§3Clyde§8) §7";

}