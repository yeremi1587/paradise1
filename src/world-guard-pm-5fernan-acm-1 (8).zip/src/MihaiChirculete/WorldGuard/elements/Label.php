<?php
declare(strict_types=1);

namespace MihaiChirculete\WorldGuard\elements;

use pocketmine\form\FormValidationException;

class Label extends Element
{
    /**
     * @return string
     */
    public function getType(): string
    {
        return "label";
    }

    /**
     * @return array
     */
    public function serializeElementData(): array
    {
        return [];
    }

    /**
     * @param mixed $value
     */
    public function validate($value): void
    {
        // Los Labels pueden recibir cualquier valor, no necesitan validación estricta
        // Esto soluciona el error "Expected null, got string"
    }
}
