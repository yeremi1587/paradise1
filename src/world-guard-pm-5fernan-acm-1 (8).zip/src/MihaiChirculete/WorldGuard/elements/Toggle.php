<?php
declare(strict_types=1);

namespace MihaiChirculete\WorldGuard\elements;

use pocketmine\form\FormValidationException;
use function is_bool;

class Toggle extends Element
{
    /** @var bool */
    protected $default;

    public function __construct(string $text, bool $default = false)
    {
        parent::__construct($text);
        $this->default = $default;
    }

    /**
     * @return bool
     */
    public function getValue(): bool
    {
        $value = parent::getValue();
        if ($value === null) {
            return $this->default;
        }
        return (bool)$value;
    }

    /**
     * @return bool
     */
    public function hasChanged(): bool
    {
        return $this->default !== $this->getValue();
    }

    /**
     * @return bool
     */
    public function getDefault(): bool
    {
        return $this->default;
    }

    /**
     * @return string
     */
    public function getType(): string
    {
        return "toggle";
    }

    /**
     * @return array
     */
    public function serializeElementData(): array
    {
        return [
            "default" => $this->default
        ];
    }

    /**
     * @param $value
     */
    public function validate($value): void
    {
        if (!is_bool($value)) {
            // Convertir a booleano en lugar de lanzar excepción
            $this->setValue((bool)$value);
        } else {
            $this->setValue($value);
        }
    }
}
