<?php
declare(strict_types=1);

namespace MihaiChirculete\WorldGuard\elements;

use pocketmine\form\FormValidationException;
use function is_string;

class Input extends Element
{
    /** @var string */
    private $placeholder;
    /** @var string */
    private $default;

    /**
     * @param string $text
     * @param string $placeholder
     * @param string $default
     */
    public function __construct(string $text, string $placeholder, string $default = "")
    {
        parent::__construct($text);
        $this->placeholder = $placeholder;
        $this->default = $default;
    }

    /**
     * @return string
     */
    public function getValue(): string
    {
        // Asegurarse de que siempre devuelva un string válido
        $value = parent::getValue();
        
        // Si el valor es null o vacío, devolver el valor por defecto
        if ($value === null || $value === "") {
            return $this->default !== null ? $this->default : "";
        }
        
        return trim((string)$value); // Asegurar que se retorna un string y eliminar espacios
    }

    /**
     * @return string
     */
    public function getPlaceholder(): string
    {
        return $this->placeholder;
    }

    /**
     * @return string
     */
    public function getDefault(): string
    {
        return $this->default;
    }

    /**
     * @return string
     */
    public function getType(): string
    {
        return "input";
    }

    /**
     * @return array
     */
    public function serializeElementData(): array
    {
        return [
            "placeholder" => $this->placeholder,
            "default" => $this->default
        ];
    }

    /**
     * @param $value
     */
    public function validate($value): void
    {
        // Si el valor es null o vacío, usar el valor por defecto
        if ($value === null || $value === "") {
            $this->setValue($this->default !== null ? $this->default : "");
        } else if (!is_string($value)) {
            // Si no es string, convertirlo
            $this->setValue((string)$value);
        } else {
            // Si ya es string, asignarlo directamente
            $this->setValue($value);
        }
    }
}
