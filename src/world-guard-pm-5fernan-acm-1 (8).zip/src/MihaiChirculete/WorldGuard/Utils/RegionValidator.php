<?php

namespace MihaiChirculete\WorldGuard\Utils;

use MihaiChirculete\WorldGuard\Region;
use pocketmine\utils\TextFormat as TF;

/**
 * Clase para validar regiones y sus flags
 */
class RegionValidator {
    /**
     * Valida el nombre de una región
     * 
     * @param string $name Nombre de la región
     * @return string|null Mensaje de error o null si es válido
     */
    public static function validateRegionName(string $name): ?string {
        // Verificar si está vacío después de quitar espacios
        $name = trim($name);
        if(empty($name)) {
            return "El nombre de la región no puede estar vacío";
        }
        
        // Verificar longitud mínima
        if(strlen($name) < 3) {
            return "El nombre de la región debe tener al menos 3 caracteres";
        }
        
        // Verificar caracteres permitidos
        if(!ctype_alnum(str_replace(['.', '_', '-'], '', $name))) {
            return "El nombre de la región solo puede contener letras, números, puntos, guiones y guiones bajos";
        }
        
        if(strlen($name) > 32) {
            return "El nombre de la región no puede tener más de 32 caracteres";
        }
        
        return null;
    }
    
    /**
     * Valida los puntos de una región
     * 
     * @param array $pos1 Primer punto
     * @param array $pos2 Segundo punto
     * @return string|null Mensaje de error o null si es válido
     */
    public static function validateRegionPoints(array $pos1, array $pos2): ?string {
        if(!isset($pos1[0], $pos1[1], $pos1[2]) || !isset($pos2[0], $pos2[1], $pos2[2])) {
            return "Los puntos de la región están incompletos";
        }
        
        // Verificar que los puntos no estén demasiado lejos (para evitar regiones enormes)
        $maxSize = 10000; // Tamaño máximo en bloques
        if(abs($pos1[0] - $pos2[0]) > $maxSize || 
           abs($pos1[1] - $pos2[1]) > $maxSize || 
           abs($pos1[2] - $pos2[2]) > $maxSize) {
            return "La región es demasiado grande. El tamaño máximo es de {$maxSize}x{$maxSize}x{$maxSize} bloques";
        }
        
        return null;
    }
    
    /**
     * Valida un flag y su valor
     * 
     * @param string $flag Nombre del flag
     * @param mixed $value Valor del flag
     * @param array $validFlags Lista de flags válidos
     * @param array $flagTypes Tipos de flags
     * @return string|null Mensaje de error o null si es válido
     */
    public static function validateFlag(string $flag, $value, array $validFlags, array $flagTypes): ?string {
        if(!isset($validFlags[$flag])) {
            return "El flag '{$flag}' no existe";
        }
        
        $type = $flagTypes[$flag] ?? "string";
        
        switch($type) {
            case "boolean":
                if($value !== "true" && $value !== "false") {
                    return "El valor de '{$flag}' debe ser 'true' o 'false'";
                }
                break;
                
            case "integer":
                if(!is_numeric($value)) {
                    return "El valor de '{$flag}' debe ser un número";
                }
                
                if($flag === "priority" && (int)$value < 0) {
                    return "La prioridad no puede ser negativa";
                }
                
                if($flag === "fly-mode" && ((int)$value < 0 || (int)$value > 3)) {
                    return "El modo de vuelo debe ser 0, 1, 2 o 3";
                }
                break;
                
            case "array":
                // Los arrays se manejan de forma especial en el código de Region.php
                break;
        }
        
        return null;
    }
    
    /**
     * Valida una región completa
     * 
     * @param string $name Nombre de la región
     * @param array $pos1 Primer punto
     * @param array $pos2 Segundo punto
     * @param string $level Nombre del mundo
     * @param array $flags Flags de la región
     * @param array $validFlags Lista de flags válidos
     * @param array $flagTypes Tipos de flags
     * @return string|null Mensaje de error o null si es válido
     */
    public static function validateRegion(string $name, array $pos1, array $pos2, string $level, array $flags, array $validFlags, array $flagTypes): ?string {
        // Validar nombre
        $nameError = self::validateRegionName($name);
        if($nameError !== null) {
            return $nameError;
        }
        
        // Validar puntos
        $pointsError = self::validateRegionPoints($pos1, $pos2);
        if($pointsError !== null) {
            return $pointsError;
        }
        
        // Validar mundo
        if(empty($level)) {
            return "El nombre del mundo no puede estar vacío";
        }
        
        // Validar flags
        foreach($flags as $flag => $value) {
            if(!isset($validFlags[$flag])) {
                continue; // Ignorar flags desconocidos
            }
            
            $flagError = self::validateFlag($flag, $value, $validFlags, $flagTypes);
            if($flagError !== null) {
                return "Error en flag '{$flag}': {$flagError}";
            }
        }
        
        return null;
    }
}
