<?php

namespace MihaiChirculete\WorldGuard\Utils;

use MihaiChirculete\WorldGuard\Region;
use pocketmine\player\Player;
use pocketmine\world\Position;

/**
 * Clase para optimizar el acceso a regiones mediante caché
 */
class RegionCache {
    /** @var array<string, Region> */
    private array $regionCache = [];
    
    /** @var array<string, string> */
    private array $positionCache = [];
    
    /** @var int */
    private int $cacheLifetime;
    
    /** @var array<string, int> */
    private array $lastAccess = [];
    
    /**
     * @param int $cacheLifetime Tiempo de vida de la caché en segundos
     */
    public function __construct(int $cacheLifetime = 60) {
        $this->cacheLifetime = $cacheLifetime;
    }
    
    /**
     * Almacena una región en la caché
     * 
     * @param string $name Nombre de la región
     * @param Region $region Objeto de región
     */
    public function cacheRegion(string $name, Region $region): void {
        $this->regionCache[$name] = $region;
        $this->lastAccess[$name] = time();
    }
    
    /**
     * Obtiene una región de la caché
     * 
     * @param string $name Nombre de la región
     * @return Region|null Región o null si no está en caché
     */
    public function getRegion(string $name): ?Region {
        if (isset($this->regionCache[$name])) {
            $this->lastAccess[$name] = time();
            return $this->regionCache[$name];
        }
        return null;
    }
    
    /**
     * Almacena una posición en la caché
     * 
     * @param Position $position Posición
     * @param string $regionName Nombre de la región
     */
    public function cachePosition(Position $position, string $regionName): void {
        $key = $this->getPositionKey($position);
        $this->positionCache[$key] = $regionName;
        $this->lastAccess[$key] = time();
    }
    
    /**
     * Obtiene una región por posición desde la caché
     * 
     * @param Position $position Posición
     * @return string|null Nombre de la región o null si no está en caché
     */
    public function getRegionNameFromPosition(Position $position): ?string {
        $key = $this->getPositionKey($position);
        if (isset($this->positionCache[$key])) {
            $this->lastAccess[$key] = time();
            return $this->positionCache[$key];
        }
        return null;
    }
    
    /**
     * Limpia las entradas antiguas de la caché
     */
    public function cleanCache(): void {
        $now = time();
        foreach ($this->lastAccess as $key => $time) {
            if ($now - $time > $this->cacheLifetime) {
                if (isset($this->regionCache[$key])) {
                    unset($this->regionCache[$key]);
                }
                if (isset($this->positionCache[$key])) {
                    unset($this->positionCache[$key]);
                }
                unset($this->lastAccess[$key]);
            }
        }
    }
    
    /**
     * Invalida toda la caché
     */
    public function invalidateCache(): void {
        $this->regionCache = [];
        $this->positionCache = [];
        $this->lastAccess = [];
    }
    
    /**
     * Invalida la caché para una región específica
     * 
     * @param string $regionName Nombre de la región
     */
    public function invalidateRegion(string $regionName): void {
        if (isset($this->regionCache[$regionName])) {
            unset($this->regionCache[$regionName]);
            unset($this->lastAccess[$regionName]);
        }
        
        // También eliminar de la caché de posiciones
        foreach ($this->positionCache as $key => $name) {
            if ($name === $regionName) {
                unset($this->positionCache[$key]);
                unset($this->lastAccess[$key]);
            }
        }
    }
    
    /**
     * Genera una clave única para una posición
     * 
     * @param Position $position Posición
     * @return string Clave única
     */
    private function getPositionKey(Position $position): string {
        return $position->getWorld()->getFolderName() . ":" . 
               floor($position->getX()) . ":" . 
               floor($position->getY()) . ":" . 
               floor($position->getZ());
    }
}
