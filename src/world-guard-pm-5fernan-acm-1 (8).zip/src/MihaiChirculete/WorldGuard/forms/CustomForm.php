<?php
declare(strict_types=1);

namespace MihaiChirculete\WorldGuard\forms;

use Closure;
use MihaiChirculete\WorldGuard\elements\Element;
use pocketmine\{form\FormValidationException, player\Player, utils\Utils};
use function array_merge;
use function gettype;
use function is_array;
use pocketmine\utils\TextFormat as TF;
use MihaiChirculete\WorldGuard\elements\Label;

class CustomForm extends Form
{
    /** @var Element[] */
    protected $elements;
    /** @var Closure */
    private $onSubmit;
    /** @var Closure|null */
    private $onClose;

    /**
     * @param string $title
     * @param Element[] $elements
     * @param Closure $onSubmit
     * @param Closure|null $onClose
     */
    public function __construct(string $title, array $elements, Closure $onSubmit, ?Closure $onClose = null)
    {
        parent::__construct($title);
        $this->elements = $elements;
        $this->onSubmit = $onSubmit;
        $this->onClose = $onClose;
        Utils::validateCallableSignature(function (Player $player, CustomFormResponse $response): void {
        }, $onSubmit);
        $this->onSubmit = $onSubmit;
        if ($onClose !== null) {
            Utils::validateCallableSignature(function (Player $player): void {
            }, $onClose);
            $this->onClose = $onClose;
        }
    }

    /**
     * @param Element ...$elements
     *
     * @return $this
     */
    public function append(Element ...$elements): self
    {
        $this->elements = array_merge($this->elements, $elements);
        return $this;
    }

    /**
     * @return string
     */
    final public function getType(): string
    {
        return self::TYPE_CUSTOM_FORM;
    }

    /**
     * @return array
     */
    protected function serializeFormData(): array
    {
        return ["content" => $this->elements];
    }

    final public function handleResponse(Player $player, $data): void
    {
        if ($data === null) {
            if ($this->onClose !== null) {
                ($this->onClose)($player);
            }
        } elseif (is_array($data)) {
            try {
                foreach ($data as $index => $value) {
                    if (!isset($this->elements[$index])) {
                        throw new FormValidationException("Element at index $index does not exist");
                    }
                    $element = $this->elements[$index];
                    try {
                        // Asegurarse de que los valores sean del tipo correcto
                        if ($element instanceof Label) {
                            // Las etiquetas no necesitan validación
                            continue;
                        }
                        
                        $element->validate($value);
                    } catch (FormValidationException $e) {
                        // Log error but continue processing
                        $player->getServer()->getLogger()->debug("Form validation error: " . $e->getMessage());
                        
                        // Establecer un valor predeterminado según el tipo de elemento
                        if ($element instanceof \MihaiChirculete\WorldGuard\elements\Input) {
                            $element->setValue("");
                        } elseif ($element instanceof \MihaiChirculete\WorldGuard\elements\Toggle) {
                            $element->setValue(false);
                        } else {
                            // Para otros tipos, intentar establecer el valor tal cual
                            try {
                                $element->setValue($value);
                            } catch (\Throwable $ex) {
                                // Si falla, no hacer nada
                            }
                        }
                    }
                }
                
                // Crear la respuesta del formulario y llamar al callback
                $response = new CustomFormResponse($this->elements);
                ($this->onSubmit)($player, $response);
            } catch (\Throwable $e) {
                $player->getServer()->getLogger()->error("Error processing form: " . $e->getMessage() . "\n" . $e->getTraceAsString());
                $player->sendMessage(TF::RED . "Ocurrió un error al procesar el formulario. Por favor, inténtalo de nuevo.");
            }
        } else {
            throw new FormValidationException("Expected array or null, got " . gettype($data));
        }
    }
}
