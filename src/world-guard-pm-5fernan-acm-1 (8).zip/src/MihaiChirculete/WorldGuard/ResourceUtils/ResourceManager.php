<?php


namespace MihaiChirculete\WorldGuard\ResourceUtils;

use pocketmine\Server;
use MihaiChirculete\WorldGuard\WorldGuard;

class ResourceManager
{
    /** Only 1 instance of this class will be allowed at all times */
    private static $instance = null;
    private $resUpdaterInstance = null;
    public ?WorldGuard $pluginInstance;
    private $serverInstance = null;
    private $pluginVersion = null;
    private array $messages = [];
    private array $lang = [];
    private array $config = [];
    private array $regions = [];

    private function __construct(WorldGuard $plugin, Server $sv)
    {
        $this->pluginInstance = $plugin;
        $this->serverInstance = $sv;
        $this->resUpdaterInstance = ResourceUpdater::getInstance($this);

        $this->pluginVersion = $this->pluginInstance->getDescription()->getVersion();
    }

    public static function getInstance(WorldGuard $plugin = null, Server $sv = null) : ResourceManager
    {
        if (ResourceManager::$instance === null)
            ResourceManager::$instance = new ResourceManager($plugin, $sv);

        return ResourceManager::$instance;
    }

    public function getConfig()
    {
        return $this->config;
    }

    public function getLanguagePack(){
        return $this->lang;
    }

    public function getMessages(){
        return $this->messages;
    }

    public function getRegions(): array
    {
        return $this->regions;
    }

    public function getPluginVersion()
    {
        return $this->pluginVersion;
    }

    public function getConfigVersion()
    {
        if (isset($this->config['version']))
            return $this->config['version'];

        return null;
    }

    public function getLanguagePackVersion()
    {
        if (isset($this->lang['version']))
            return $this->lang['version'];

        return null;
    }

    public function getMessagesVersion()
    {
        if (isset($this->messages['version']))
            return $this->messages['version'];

        return null;
    }


    public function loadResources()
    {
        if (!is_dir($path = $this->pluginInstance->getDataFolder())) {
            mkdir($path);
        }
        $this->loadConfig($path);
        $this->loadLanguagePack($path);
        $this->loadMessages($path);
        $this->loadRegions($path);
    }

    public function loadRegions($path)
    {
        /**
         * load regions if file exists and if not create a file
         */
        if (is_file($path . 'regions.yml')) {
            try {
                $this->regions = yaml_parse_file($path . 'regions.yml') ?? [];
                
                // Verificar si hay regiones corruptas y repararlas
                foreach($this->regions as $name => $data) {
                    if(!isset($data['pos1']) || !isset($data['pos2']) || !isset($data['level']) || !isset($data['flags'])) {
                        $this->pluginInstance->getLogger()->warning("Región corrupta encontrada: $name. Eliminando...");
                        unset($this->regions[$name]);
                    }
                }
            } catch(\Exception $e) {
                $this->pluginInstance->getLogger()->error("Error al cargar regiones: " . $e->getMessage());
                $this->pluginInstance->getLogger()->error("Creando archivo de respaldo y reiniciando regiones...");
                
                // Crear respaldo del archivo corrupto
                if(copy($path . 'regions.yml', $path . 'regions_backup_' . time() . '.yml')) {
                    $this->pluginInstance->getLogger()->info("Respaldo creado correctamente.");
                }
                
                $this->regions = [];
            }
        } else {
            yaml_emit_file($path . 'regions.yml', []);
            $this->regions = [];
        }
    }

    public function saveRegions($regions): bool
    {
        $this->regions = $regions;

        $data = [];
        foreach ($regions as $name => $region) {
            try {
                $data[$name] = $region->toArray();
            } catch(\Exception $e) {
                $this->pluginInstance->getLogger()->error("Error al guardar la región $name: " . $e->getMessage());
                continue;
            }
        }
        
        try {
            yaml_emit_file($this->pluginInstance->getDataFolder() . 'regions.yml', $data);
            return true;
        } catch(\Exception $e) {
            $this->pluginInstance->getLogger()->error("Error al guardar el archivo de regiones: " . $e->getMessage());
            return false;
        }
    }

    public function loadConfig($path)
    {
        /**
         * load config if file exists and if not create a file
         */
        if (is_file($path . 'config.yml')) {
            $this->config = yaml_parse_file($path . 'config.yml');
        } else {
            $this->config = $this->resUpdaterInstance->getDefaultConfig();

            yaml_emit_file($path . 'config.yml', $this->config);
        }
    }


    public function loadLanguagePack()
    {
        $path = $this->pluginInstance->getDataFolder();
        $langFile = "lang_" . $this->config["language"] . ".yml";
        //if not in phar ressource ord plugin_folder
        if (!is_file($path . $langFile) && !$this->pluginInstance->saveResource($langFile)) {
            //use en lang file
            $langFile = "lang_en.yml";
            $this->config["language"] = "en";
            yaml_emit_file($path . 'config.yml', $this->config);
            //create default en lang file
            if (!is_file($path . $langFile) && !$this->pluginInstance->saveResource($langFile)) {
                $this->lang = $this->resUpdaterInstance->getDefaultLanguagePack();
                yaml_emit_file($path . 'lang_en.yml', $this->lang);
                return;
            }
        }
        // load language
        $this->lang = yaml_parse_file($path . $langFile);
    }

    public function loadMessages($path)
    {
        /**
         * load messages if file exists and if not write the default ones
         */
        if (is_file($path . 'messages.yml')) {
            $this->messages = yaml_parse_file($path . 'messages.yml');
        } else {
            $this->messages = $this->resUpdaterInstance->getDefaultMessages();

            yaml_emit_file($path . 'messages.yml', $this->messages);
        }
    }

    public function saveConfig($config)
    {
        $this->config = $config;

        $path = $this->pluginInstance->getDataFolder();
        yaml_emit_file($path . 'config.yml', $this->config);
    }

    public function saveMessages($messages)
    {
        $this->messages = $messages;

        $path = $this->pluginInstance->getDataFolder();
        yaml_emit_file($path . 'messages.yml', $this->messages);
    }

    public function saveLanguagePack($langPack)
    {
        $this->lang = $langPack;

        $path = $this->pluginInstance->getDataFolder();
        yaml_emit_file($path . "lang_" . $this->config["language"] . ".yml", $this->lang);
    }

}
